*&---------------------------------------------------------------------*
*& Include ZFIR_UUID_CFDI_UPDATE_FRM00
*&---------------------------------------------------------------------*
*& Lectura y parseo del archivo CSV desde equipo local
*& Bucle principal de procesamiento de registros
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*& Form FRM_LEER_CSV_LOCAL
*&---------------------------------------------------------------------*
*& Lee el archivo CSV desde el equipo local del usuario usando
*& cl_gui_frontend_services=>gui_upload y parsea cada línea.
*& Maneja BOM UTF-8 y salta la cabecera.
*&---------------------------------------------------------------------*
FORM frm_leer_csv_local.

  DATA: lt_file_t   TYPE TABLE OF string,
        lv_line     TYPE string,
        ls_datos    TYPE gty_csv_data,
        lv_index    TYPE i,
        lv_filename TYPE string.

* Convertir nombre de fichero a string
  lv_filename = p_file.

* Subir el archivo desde equipo local
  CALL METHOD cl_gui_frontend_services=>gui_upload
    EXPORTING
      filename                = lv_filename
    CHANGING
      data_tab                = lt_file_t
    EXCEPTIONS
      file_open_error         = 1
      file_read_error         = 2
      no_batch                = 3
      gui_refuse_filetransfer = 4
      invalid_type            = 5
      no_authority            = 6
      unknown_error           = 7
      bad_data_format         = 8
      header_not_allowed      = 9
      separator_not_allowed   = 10
      header_too_long         = 11
      unknown_dp_error        = 12
      access_denied           = 13
      dp_out_of_memory        = 14
      disk_full               = 15
      dp_timeout              = 16
      not_supported_by_gui    = 17
      error_no_gui            = 18
      OTHERS                  = 19.

  IF sy-subrc <> 0.
    MESSAGE e398(00) WITH 'Error al leer el archivo CSV.'
                          'Verifique la ruta y permisos.' '' ''.
    RETURN.
  ENDIF.

* Verificar que se han leído datos
  IF lt_file_t IS INITIAL.
    MESSAGE s398(00) WITH 'El archivo CSV está vacío.' '' '' ''
                          DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

* Limpiar tabla de datos
  REFRESH gt_csv_data.

* Recorrer las líneas del archivo
  LOOP AT lt_file_t INTO lv_line.
    lv_index = sy-tabix.

*   Primera línea: puede tener BOM UTF-8, siempre es cabecera -> saltar
    IF lv_index = 1.
*     Eliminar BOM UTF-8 si existe (bytes EF BB BF al inicio)
*     En strings ABAP pueden aparecer como caracteres especiales al inicio
      PERFORM frm_eliminar_bom CHANGING lv_line.
      CONTINUE. " Saltar línea de cabecera
    ENDIF.

*   Ignorar líneas vacías
    IF lv_line IS INITIAL.
      CONTINUE.
    ENDIF.

*   Parsear la línea CSV (separador: punto y coma)
    CLEAR ls_datos.
    SPLIT lv_line AT ';' INTO
      ls_datos-rfc_emisor
      ls_datos-rfc_receptor
      ls_datos-serie
      ls_datos-folio
      ls_datos-fecha
      ls_datos-total
      ls_datos-tipocomprobante
      ls_datos-uuid.

*   Limpiar espacios
    CONDENSE ls_datos-rfc_emisor NO-GAPS.
    CONDENSE ls_datos-rfc_receptor NO-GAPS.
    CONDENSE ls_datos-serie NO-GAPS.
    CONDENSE ls_datos-folio NO-GAPS.
    CONDENSE ls_datos-uuid NO-GAPS.
    CONDENSE ls_datos-tipocomprobante NO-GAPS.

*   Convertir UUID y tipo comprobante a mayúsculas
    TRANSLATE ls_datos-uuid TO UPPER CASE.
    TRANSLATE ls_datos-tipocomprobante TO UPPER CASE.

*   Si no hay UUID, saltar el registro sin error
    IF ls_datos-uuid IS INITIAL.
      CONTINUE.
    ENDIF.

*   Validar formato UUID (36 chars con guiones)
    IF strlen( ls_datos-uuid ) <> 36.
      CLEAR gs_log.
      gs_log-icon         = gc_icon_err.
      gs_log-rfc_emisor   = ls_datos-rfc_emisor.
      gs_log-rfc_receptor = ls_datos-rfc_receptor.
      gs_log-serie        = ls_datos-serie.
      gs_log-folio        = ls_datos-folio.
      gs_log-tipo         = ls_datos-tipocomprobante.
      gs_log-uuid         = ls_datos-uuid.
      gs_log-mensaje      = 'UUID con formato incorrecto (debe ser 36 caracteres)'.
      APPEND gs_log TO gt_log.
      gv_error = gv_error + 1.
      CONTINUE.
    ENDIF.

*   Añadir a tabla de datos válidos
    APPEND ls_datos TO gt_csv_data.

  ENDLOOP.

ENDFORM.                    " FRM_LEER_CSV_LOCAL

*&---------------------------------------------------------------------*
*& Form FRM_ELIMINAR_BOM
*&---------------------------------------------------------------------*
*& Elimina el BOM UTF-8 (EF BB BF) del inicio de una línea si existe
*&---------------------------------------------------------------------*
FORM frm_eliminar_bom
  CHANGING pv_line TYPE string.

  DATA: lv_len    TYPE i,
        lv_char1  TYPE x LENGTH 1,
        lv_hex    TYPE xstring,
        lv_first3 TYPE string.

* El BOM en UTF-8 son los bytes EF BB BF. En SAP pueden manifestarse
* como caracteres especiales al inicio del string. Comprobamos si los
* primeros caracteres son no-imprimibles y los eliminamos.
  lv_len = strlen( pv_line ).
  IF lv_len >= 1.
*   Verificar si el primer carácter es un carácter BOM conocido
*   (en codificación interna SAP puede aparecer como FEFF o similar)
    DATA: lv_first TYPE c LENGTH 1.
    lv_first = pv_line+0(1).
*   Si el primer carácter tiene valor hex > 7F, probablemente es BOM
    DATA: lv_cp TYPE i.
    lv_cp = cl_abap_conv_out_ce=>uccp( lv_first ).
    IF lv_cp = 65279     " FEFF = BOM UTF-16/UTF-8 manifestado
    OR lv_cp = 239.      " EF = primer byte BOM UTF-8
*     Eliminar hasta 3 caracteres BOM del inicio
      IF lv_len >= 3.
        DATA: lv_cp2 TYPE i,
              lv_cp3 TYPE i.
        lv_cp2 = cl_abap_conv_out_ce=>uccp( pv_line+1(1) ).
        lv_cp3 = cl_abap_conv_out_ce=>uccp( pv_line+2(1) ).
        IF ( lv_cp = 239 AND lv_cp2 = 187 AND lv_cp3 = 191 ). " EF BB BF
          pv_line = pv_line+3.
        ELSEIF lv_cp = 65279. " FEFF como un solo carácter
          pv_line = pv_line+1.
        ENDIF.
      ELSEIF lv_cp = 65279.
        pv_line = pv_line+1.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.                    " FRM_ELIMINAR_BOM

*&---------------------------------------------------------------------*
*& Form FRM_PROCESAR_REGISTROS
*&---------------------------------------------------------------------*
*& Bucle principal: para cada registro del CSV determina tipo de
*& factura, localiza el documento y actualiza el UUID.
*&---------------------------------------------------------------------*
FORM frm_procesar_registros.

  DATA: ls_datos      TYPE gty_csv_data,
        lv_tipo_fac   TYPE c,            " C=Compra, V=Venta, I=Interco
        lv_emisor_bk  TYPE char10,       " BUKRS o LIFNR del emisor
        lv_receptor_bk TYPE char10,      " BUKRS o KUNNR del receptor
        lv_gjahr      TYPE gjahr,        " Ejercicio extraído de la fecha
        lv_error      TYPE c,
        lv_total_num  TYPE p DECIMALS 0. " Total numérico para comparación

* Inicializar contadores
  CLEAR: gv_total, gv_ok, gv_warning, gv_error.

* Recorrer cada registro del CSV
  LOOP AT gt_csv_data INTO ls_datos.
    gv_total = gv_total + 1.
    CLEAR: lv_tipo_fac, lv_emisor_bk, lv_receptor_bk, lv_error.

*   Extraer ejercicio (año) de la fecha del CSV
*   Formato: DD/MM/YYYY HH:MM:SS a. m.
    PERFORM frm_extraer_anio
      USING ls_datos-fecha
      CHANGING lv_gjahr.

    IF lv_gjahr IS INITIAL.
      CLEAR gs_log.
      gs_log-icon         = gc_icon_err.
      gs_log-rfc_emisor   = ls_datos-rfc_emisor.
      gs_log-rfc_receptor = ls_datos-rfc_receptor.
      gs_log-serie        = ls_datos-serie.
      gs_log-folio        = ls_datos-folio.
      gs_log-tipo         = ls_datos-tipocomprobante.
      gs_log-uuid         = ls_datos-uuid.
      gs_log-mensaje      = 'No se pudo extraer el año de la fecha del CSV'.
      APPEND gs_log TO gt_log.
      gv_error = gv_error + 1.
      CONTINUE.
    ENDIF.

*   Convertir total del CSV a numérico (quitar puntos separadores de miles)
    PERFORM frm_convertir_total
      USING ls_datos-total
      CHANGING lv_total_num.

*   Determinar tipo de factura (Compra/Venta/Intercompany)
    PERFORM frm_tipo_factura
      USING    ls_datos
      CHANGING lv_tipo_fac
               lv_emisor_bk
               lv_receptor_bk
               lv_error.

    IF lv_error = 'X'.
*     Error ya registrado en gt_log dentro de frm_tipo_factura
      gv_error = gv_error + 1.
      CONTINUE.
    ENDIF.

*   Filtro opcional por sociedad (S_BUKRS)
    IF s_bukrs IS NOT INITIAL.
      CASE lv_tipo_fac.
        WHEN gc_tipo_compra.
          IF lv_receptor_bk NOT IN s_bukrs.
            CONTINUE.
          ENDIF.
        WHEN gc_tipo_venta.
          IF lv_emisor_bk NOT IN s_bukrs.
            CONTINUE.
          ENDIF.
        WHEN gc_tipo_interco.
          IF lv_emisor_bk NOT IN s_bukrs AND lv_receptor_bk NOT IN s_bukrs.
            CONTINUE.
          ENDIF.
      ENDCASE.
    ENDIF.

*   Procesar según tipo de factura
    CASE lv_tipo_fac.
      WHEN gc_tipo_compra.
        " Compra: sociedad = receptor, proveedor = emisor
        PERFORM frm_procesar_compra
          USING ls_datos lv_receptor_bk lv_emisor_bk lv_gjahr lv_total_num.

      WHEN gc_tipo_venta.
        " Venta: sociedad = emisor, cliente = receptor
        PERFORM frm_procesar_venta
          USING ls_datos lv_emisor_bk lv_receptor_bk lv_gjahr lv_total_num.

      WHEN gc_tipo_interco.
        " Intercompany: procesar ambos lados
        PERFORM frm_procesar_intercompany
          USING ls_datos lv_emisor_bk lv_receptor_bk lv_gjahr lv_total_num.

    ENDCASE.

  ENDLOOP.

ENDFORM.                    " FRM_PROCESAR_REGISTROS

*&---------------------------------------------------------------------*
*& Form FRM_EXTRAER_ANIO
*&---------------------------------------------------------------------*
*& Extrae el año (GJAHR) del campo fecha del CSV
*& Formato esperado: DD/MM/YYYY HH:MM:SS a. m.
*&---------------------------------------------------------------------*
FORM frm_extraer_anio
  USING    pv_fecha TYPE char30
  CHANGING pv_gjahr TYPE gjahr.

  DATA: lv_fecha TYPE string,
        lv_anio  TYPE string.

  CLEAR pv_gjahr.
  lv_fecha = pv_fecha.
  CONDENSE lv_fecha NO-GAPS.

* Verificar longitud mínima (DD/MM/YYYY = 10 chars)
  IF strlen( lv_fecha ) >= 10.
*   El año está en las posiciones 6-9 (después de DD/MM/)
    lv_anio = lv_fecha+6(4).
*   Verificar que sea numérico
    IF lv_anio CO '0123456789'.
      pv_gjahr = lv_anio.
    ENDIF.
  ENDIF.

ENDFORM.                    " FRM_EXTRAER_ANIO

*&---------------------------------------------------------------------*
*& Form FRM_CONVERTIR_TOTAL
*&---------------------------------------------------------------------*
*& Convierte el campo Total del CSV (con puntos de miles) a numérico
*& Ejemplo: "1.514.960.000" -> 1514960000
*&---------------------------------------------------------------------*
FORM frm_convertir_total
  USING    pv_total_str TYPE char25
  CHANGING pv_total_num TYPE p.

  DATA: lv_total_str TYPE string.

  CLEAR pv_total_num.
  lv_total_str = pv_total_str.
  CONDENSE lv_total_str NO-GAPS.

* Eliminar puntos (separadores de miles)
  REPLACE ALL OCCURRENCES OF '.' IN lv_total_str WITH ''.

* Eliminar comas (si las hubiera como decimal)
  REPLACE ALL OCCURRENCES OF ',' IN lv_total_str WITH ''.

* Convertir a numérico
  IF lv_total_str CO '0123456789'.
    pv_total_num = lv_total_str.
  ENDIF.

ENDFORM.                    " FRM_CONVERTIR_TOTAL
