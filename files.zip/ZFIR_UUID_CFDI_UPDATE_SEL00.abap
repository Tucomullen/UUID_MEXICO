*&---------------------------------------------------------------------*
*& Include ZFIR_UUID_CFDI_UPDATE_SEL00
*&---------------------------------------------------------------------*
*& Lógica de pantalla de selección: F4 help y validaciones
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*& Form FRM_F4_FICHERO_CSV
*&---------------------------------------------------------------------*
*& Diálogo F4 para seleccionar archivo CSV desde equipo local
*&---------------------------------------------------------------------*
FORM frm_f4_fichero_csv.

  DATA: lt_filetable TYPE filetable,
        ls_file      TYPE file_table,
        lv_rc        TYPE i,
        lv_action    TYPE i.

  CALL METHOD cl_gui_frontend_services=>file_open_dialog
    EXPORTING
      window_title      = 'Seleccionar archivo CSV'
      default_extension = 'CSV'
      file_filter       = 'Archivos CSV (*.csv)|*.csv|Todos los archivos (*.*)|*.*'
    CHANGING
      file_table        = lt_filetable
      rc                = lv_rc
      user_action       = lv_action
    EXCEPTIONS
      file_open_dialog_failed = 1
      cntl_error              = 2
      error_no_gui            = 3
      not_supported_by_gui    = 4
      OTHERS                  = 5.

  IF sy-subrc = 0 AND lv_action = 0.
    READ TABLE lt_filetable INTO ls_file INDEX 1.
    IF sy-subrc = 0.
      p_file = ls_file-filename.
    ENDIF.
  ENDIF.

ENDFORM.                    " FRM_F4_FICHERO_CSV

*&---------------------------------------------------------------------*
*& Form FRM_VALIDAR_SELECCION
*&---------------------------------------------------------------------*
*& Validaciones de la pantalla de selección
*&---------------------------------------------------------------------*
FORM frm_validar_seleccion.

  DATA: lv_file_str TYPE string,
        lv_len      TYPE i.

* Verificar que el archivo tiene extensión .csv
  lv_file_str = p_file.
  lv_len = strlen( lv_file_str ).
  IF lv_len > 4.
    DATA: lv_extension TYPE string.
    lv_extension = lv_file_str+( lv_len - 4 )(4).
    TRANSLATE lv_extension TO UPPER CASE.
    IF lv_extension <> '.CSV'.
      MESSAGE e398(00) WITH 'El archivo seleccionado'
                            'no tiene extensión .CSV.' '' ''.
    ENDIF.
  ENDIF.

ENDFORM.                    " FRM_VALIDAR_SELECCION
